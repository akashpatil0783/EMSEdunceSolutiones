﻿using EMS.BusinessAccessLayer.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EMS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeAPIController : ControllerBase
    {
        private readonly IEmployeeServices _employeeServices;
        private readonly ILogger<EmployeeAPIController> _logger;
        public EmployeeAPIController(IEmployeeServices employeeServices, ILogger<EmployeeAPIController> logger)
        {
            _employeeServices = employeeServices;
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Get()
        {
            _logger.LogInformation("GET/api/Employee Called");
            try
            {
                var data = _employeeServices.GetAllEmployee();
                return Ok(data);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "error fecting active employee");
                return StatusCode(500, "Internal Sevrel error");
            }
        }

    }
}
