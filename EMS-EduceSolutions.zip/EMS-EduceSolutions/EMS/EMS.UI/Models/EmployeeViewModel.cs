﻿using EMS.Domain.Entity;

namespace EMS.UI.Models
{
    public class EmployeeViewModel
    {
        public Employee employee { get; set; }

        public List<Employee> employeelist { get; set; }
        public List<City> citieslist { get; set; }

        public List<State> sataeslist { get; set; }


    }
}
