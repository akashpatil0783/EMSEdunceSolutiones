﻿using EMS.BusinessAccessLayer.Interface;
using EMS.Domain.Entity;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace EMS.DataAccessLayer.Services
{
    public class EmployeeServices : IEmployeeServices
    {
        private readonly ILogger<EmployeeServices> _logger;
        private readonly string _connectionstring;
        public EmployeeServices(ILogger<EmployeeServices> logger, IConfiguration configuration)
        {
            _logger = logger;
            _connectionstring = configuration.GetConnectionString("DefultConnctionesstring");
        }

        public int Add(Employee employee)
        {
            _logger.LogInformation("Start to Add");
            int data = 0;
            try
            {

                SqlConnection con = new SqlConnection(_connectionstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("EmployeeInsert", con);
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@FullName", employee.FullName);
                cmd.Parameters.AddWithValue("@Email", employee.Email);
                cmd.Parameters.AddWithValue("@State", employee.State);
                cmd.Parameters.AddWithValue("@City", employee.City);
                cmd.Parameters.AddWithValue("@DateOfJoining", employee.DateOfJoining);
                cmd.Parameters.AddWithValue("@IsActive", employee.IsActive);
                cmd.Parameters.AddWithValue("@CreatedBy", 1);
                cmd.Parameters.AddWithValue("@CreateOn", DateTime.Now);
                cmd.Parameters.AddWithValue("@UpdatedBy", 1);
                cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                data = cmd.ExecuteNonQuery();
                con.Close();
                _logger.LogInformation("Method of Add Is End");

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "error in Add Method");
            }

            return data;
        }

        public int DeleteEmployee(int id)
        {
            _logger.LogInformation("Start to DeleteEmployee");
            int data = 0;
            try
            {

                SqlConnection con = new SqlConnection(_connectionstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("DeleteEmployees");
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmployeeId", id);
                data = cmd.ExecuteNonQuery();
                return data;
                _logger.LogInformation("End to DeleteEmployee");

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "error in DeleteEmployee");
            }
            return data;


        }

        public List<Employee> GetAllEmployee()
        {

            List<Employee> list = new List<Employee>();
            try
            {

                SqlConnection con = new SqlConnection(_connectionstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("EmployeeALlList");
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Employee emp = new Employee();
                    emp.EmployeeId = Convert.ToInt32(dr["EmployeeId"]);
                    emp.FullName = Convert.ToString(dr["FullName"]);
                    emp.Email = Convert.ToString(dr["Email"]);
                    emp.State = Convert.ToString(dr["Statename"]);
                    emp.City = Convert.ToString(dr["Cityname"]);
                    emp.DateOfJoining = Convert.ToDateTime(dr["DateOfJoining"]);
                    emp.IsActive = Convert.ToBoolean(dr["IsActive"]);

                    list.Add(emp);

                }
                dr.Close();
                con.Close();




            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "error in GetAllEmployee Method");
            }

            return list;

        }

        public Employee GetEmployeeBYId(int id)
        {
            _logger.LogInformation("Fecting employee By Id", id);
            Employee emp = new Employee();
            try
            {

                SqlConnection con = new SqlConnection(_connectionstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("EmployeeGetById");
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmployeeId", id);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    emp.EmployeeId = Convert.ToInt32(dr["EmployeeId"]);
                    emp.FullName = Convert.ToString(dr["FullName"]);
                    emp.Email = Convert.ToString(dr["Email"]);
                    emp.State = Convert.ToString(dr["State"]);
                    emp.City = Convert.ToString(dr["City"]);
                    emp.DateOfJoining = Convert.ToDateTime(dr["DateOfJoining"]);
                    emp.IsActive = Convert.ToBoolean(dr["IsActive"]);
                    emp.CreatedBy = Convert.ToInt32(dr["CreatedBy"]);
                    emp.CreatedOn = Convert.ToDateTime(dr["CreateOn"]);
                    emp.UpdatedBy = Convert.ToInt32(dr["UpdatedBy"]);
                    emp.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);

                }
                dr.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "error in DeleteEmployee");
                throw;
            }
            return emp;
        }

        public int Update(Employee employee)
        {
            _logger.LogInformation("Updaeting employee", employee.EmployeeId);
            try
            {

                SqlConnection con = new SqlConnection(_connectionstring);
                SqlCommand cmd = new SqlCommand("UpdateEmployee");
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmployeeId", employee.EmployeeId);
                cmd.Parameters.AddWithValue("@FullName", employee.FullName);
                cmd.Parameters.AddWithValue("@Email", employee.Email);
                cmd.Parameters.AddWithValue("@State", employee.State);
                cmd.Parameters.AddWithValue("@City", employee.City);
                cmd.Parameters.AddWithValue("@DateOfJoining", employee.DateOfJoining);
                cmd.Parameters.AddWithValue("@IsActive", employee.IsActive);
                cmd.Parameters.AddWithValue("@CreatedBy", 1);
                cmd.Parameters.AddWithValue("@CreateOn", DateTime.Now);
                cmd.Parameters.AddWithValue("@UpdatedBy", 1);
                cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                cmd.ExecuteNonQuery();
                con.Close();

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "error in Update mehod");
                throw;
            }

            return 0;
        }

        public List<State> StateDropDown()
        {
            List<State> list = new List<State>();
            try
            {
                SqlConnection con = new SqlConnection(_connectionstring);

                SqlCommand cmd = new SqlCommand("SateDropDwon");
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    State satae = new State();
                    satae.StateId = Convert.ToInt32(dr["StateId"]);
                    satae.StateName = Convert.ToString(dr["StateName"]);
                    list.Add(satae);

                }
                dr.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "error in  StateDropDown mehod");
                throw;
            }

            return list;

        }

        public List<City> CityDropDown()
        {
            List<City> list = new List<City>();
            try
            {
                SqlConnection con = new SqlConnection(_connectionstring);
                SqlCommand cmd = new SqlCommand("CityDropDown");
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    City city = new City();
                    city.CityId = Convert.ToInt32(dr["CityId"]);
                    city.CityName = Convert.ToString(dr["CityName"]);
                    list.Add(city);
                }
                dr.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "error in  CityDropDown mehod");
                throw;
            }

            return list;

        }
    }
}
