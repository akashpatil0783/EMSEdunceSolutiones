﻿using EMS.BusinessAccessLayer.Interface;
using EMS.UI.Models;
using Microsoft.AspNetCore.Mvc;

namespace EMS.UI.Controllers
{
    public class EmployeeInfomationesController : Controller
    {
        private readonly IEmployeeServices _employeeServices;
        private readonly ILogger<EmployeeInfomationesController> _logger;
        public EmployeeInfomationesController(IEmployeeServices employeeServices, ILogger<EmployeeInfomationesController> logger)
        {
            _employeeServices = employeeServices;
            _logger = logger;
        }
        public IActionResult Index()
        {
            _logger.LogInformation("Employee Index Page Requrired");
            try
            {
                var model = new EmployeeViewModel
                {
                    employeelist = _employeeServices.GetAllEmployee(),
                    sataeslist = _employeeServices.StateDropDown(),
                    citieslist = _employeeServices.CityDropDown(),
                    employee = new Domain.Entity.Employee()
                };
                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Errror in the Index fecting file");
                return Content(ex.Message);
            }
        }

        public IActionResult Create(EmployeeViewModel employeeViewModel)
        {
            _logger.LogInformation("Create/Update Employee Recired");
            try
            {
                var data = employeeViewModel.employee;
                if (data.EmployeeId != 0)
                {
                    _logger.LogInformation("Updateing the Employee", data.EmployeeId);
                    _employeeServices.Update(data);
                }
                else
                {
                    _logger.LogInformation("Createing the Employee");
                    _employeeServices.Add(data);
                }
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Errror in the Create  Action");
                return Content(ex.Message);
            }
        }

        public IActionResult GetById(int id)
        {
            _logger.LogInformation("Edit request for EmployeeId", id);
            try
            {
                var model = new EmployeeViewModel
                {
                    employeelist = _employeeServices.GetAllEmployee(),
                    sataeslist = _employeeServices.StateDropDown(),
                    citieslist = _employeeServices.CityDropDown(),
                    employee = _employeeServices.GetEmployeeBYId(id)
                };
                return View("Index", model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "error loading edit");
                return Content(ex.Message);
            }

        }

        public IActionResult Delete(int id)
        {
            _logger.LogInformation("Delete reqreures fro employee id", id);
            try
            {
                var data = _employeeServices.DeleteEmployee(id);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in the Delete employee");
                return Content(ex.Message);
            }
        }
        public IActionResult Employeedeatils(int id)
        {
            _logger.LogInformation("Employeedeatils reureired for id", id);
            try
            {
                var Data = _employeeServices.GetEmployeeBYId(id);
                var Model = new EmployeeViewModel
                {
                    employeelist = _employeeServices.GetAllEmployee(),
                    employee = _employeeServices.GetEmployeeBYId(id),
                    sataeslist = _employeeServices.StateDropDown(),
                    citieslist = _employeeServices.CityDropDown(),
                };
                return PartialView("Employeedeatils", Model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "error loading employee detils");
                return Content(ex.Message);
            }
        }
    }
}

