﻿using EMS.Domain.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.BusinessAccessLayer.Interface
{
    public interface IEmployeeServices
    {
        public int Add(Employee employee);

        public int Update(Employee employee);

        public List<Employee> GetAllEmployee();

        public Employee GetEmployeeBYId(int id);

        public int DeleteEmployee(int id);

        public List<State> StateDropDown();

        public List<City> CityDropDown();
    }
}

