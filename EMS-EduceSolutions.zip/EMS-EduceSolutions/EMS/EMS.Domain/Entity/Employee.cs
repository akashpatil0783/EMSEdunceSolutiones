﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Domain.Entity
{
   public class Employee:BaseAuditEnitity
    {

        public int EmployeeId { get; set; }
        [Required(ErrorMessage = "This field is required.")]
        [StringLength(20, ErrorMessage = "Maximum 20 characters are allowed.")]
        public string FullName { get; set; } = null!;
        [Required(ErrorMessage = "Email is mandatory.")]
        [EmailAddress(ErrorMessage = "Invalid email format.")]
        public string Email { get; set; } = null!;
        [Required(ErrorMessage = "Plase Select the State")]
        public string State { get; set; } = null!;
        [Required(ErrorMessage ="Plase Select the city")]
        public string City { get; set; }=null!;
        [Required(ErrorMessage = "Date Of Joining is required.")]
        public DateTime? DateOfJoining { get; set; }
    }
}
